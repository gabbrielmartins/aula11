# 11-Sazonalidade-Suavizacao
Suavização e decomposição por meio de médias móveis.
